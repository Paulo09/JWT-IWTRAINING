import express from 'express';
import RotasPublicas from './routes/RotasPublicas.js';
import RotasPrivadas from './routes/RotasPrivadas.js';

const app = express();
app.use(express.json());

app.use(RotasPublicas);
app.use(RotasPrivadas);


app.listen(8000, function() {
    console.log("Servidor executando...");
})